package com.example.logginapp.ui.login;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.logginapp.databinding.FragmentLoginBinding;

import com.example.logginapp.R;

public class LoginFragment extends Fragment {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        usernameEditText = view.findViewById(R.id.username);
        passwordEditText = view.findViewById(R.id.password);
        loginButton = view.findViewById(R.id.login);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Lógica de inicio de sesión
                // Aquí puedes verificar las credenciales ingresadas y, si son válidas, navegar a la Activity2

                if (areCredentialsValid(username, password)) {
                    navigateToActivity2();
                } else {
                    // Mostrar un mensaje de error o realizar alguna acción en caso de credenciales inválidas
                }
            }
        });

        return view;
    }

    private boolean areCredentialsValid(String username, String password) {
        // Aquí puedes implementar la lógica para verificar las credenciales
        // Por ejemplo, comparar con credenciales almacenadas en la base de datos o en algún servicio de autenticación
        // Si las credenciales son válidas, devuelve true; de lo contrario, devuelve false.

        String usuario = usernameEditText.getText().toString();
        String contrasenya = passwordEditText.getText().toString();

        return true;
    }

    private void navigateToActivity2() {
        Intent intent = new Intent(getActivity(), LoggedInUserView.class);
        startActivity(intent);
        // Opcionalmente, puedes finalizar la actividad actual (LoginActivity) si no deseas volver a ella desde Activity2.
         getActivity().finish();
    }
}

